const navOpen = document.querySelector('.nav_open');
const navBar = document.querySelector('.nav_link');
const navClose = document.querySelector('.nav_close')

navOpen.addEventListener('click', ()=>{
    navBar.classList.add('active');
})

navClose.addEventListener('click', ()=>{
    navBar.classList.remove('active');
})